let data = (function() {

    let groupInfo =
        [
         'Black Cutscene',        //组名
         'lightyellow'     //颜色
        ];

    let commandInfos = [
        {
            command: ['落下帷幕', 'yield game.$plugins["workcrafts"]["Black Cutscene"].show();', '落下帷幕', 0, true, 'red', 'white', ['Black Cutscene_升起帷幕']],
        },
        {
            command: ['升起帷幕', 'game.$plugins["workcrafts"]["Black Cutscene"].hide();', '升起帷幕', 0, true, 'red', 'white'],
        },
        {
            command: ['【配置】', '.pragma library\r\n\r\nvar waittime = %1;\r\nvar colorchange = %2;', '【配置】', 0, true, 'red', 'white'],
            params: [
                ['*切换时长', 'number', true, 0, 1000, 'green'],
                ['*切换颜色', 'string', true, 2, [['白', '红', '绿', '蓝', '黑', '灰', '黄'], ['white', 'red', 'green', 'blue', 'black', 'gray', 'yellow'], 'black'], 'green'],
            ],
        },
    ];



    return {groupInfo, commandInfos};

})();

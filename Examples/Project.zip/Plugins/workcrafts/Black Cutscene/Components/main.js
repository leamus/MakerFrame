//.pragma library

//导入配置文件
.import 'Config.js' as Config

//导入qml组件
.import QtQml 2.14 as QtQml



/*
  组件父对象：
    game.$sys.screen / itemComponentsContainer：固定屏幕上
    game.$sys.scene / game.$sys.scene：会改变大小
    game.$sys.container / itemContainer：会改变大小和随地图移动
*/



//描述
var $description = '示例插件描述';


//可以 全局定义 其他 变量 或 函数；游戏中使用 game.$plugins['模块名'] 来调用；
//var arrObjs = [];
var obj = null;
var black_switch = false
//export {black_switch}

function show() {
    if(obj) {
        game.pause();
        game.wait(Config.waittime);
        //obj.opacity = 0;
        obj.animation.from = 0;
        obj.animation.to = 1;
        obj.animation.start();
        
        //yield game.wait(1000);
    }
}

function hide() {
    if(obj) {
        game.goon()
        //obj.opacity = 1;
        obj.animation.from = 1;
        obj.animation.to = 0;
        obj.animation.start();
        //game.goon()
    }
}

//载入 函数（游戏第一次运行时会执行，所以在这里创建组件）
function $load() {
    //console.debug('[Plugins]load：', game.$plugins['Text'].description, this, this === game.$plugins['Text']);

    var comp = Qt.createComponent("black.qml");
    //console.debug(comp)
    function statusChanged() {
        if (comp.status === QtQml.Component.Ready) {
            //创建组件对象
            obj = comp.createObject(game.$sys.scene);
            //arrObjs.push(obj);
        }
        else if (comp.status === QtQml.Component.Error) {
            console.error(comp.errorString());
        }
    }
    if(comp.status === QtQml.Component.Loading)
        comp.statusChanged.connect(statusChanged);
    else
        statusChanged();


}

//初始化 函数（游戏运行 或 读取存档 会运行，用来初始化）
function $init() {
    console.debug('[Plugins]init');

    if(obj)
        obj.visible = true;

    //for(let to of arrObjs)
    //    to.visible = true;
}

//释放 函数（读取存档 或 退出游戏时会执行，用来清理工作）
function $release() {
    console.debug('[Plugins]release');

    obj.visible = false;

    //for(let to of arrObjs)
    //    to.visible = false;
}

//卸载 函数
function $unload() {
    console.debug('[Plugins]unload');

    obj.destroy();
    obj = null;

    //for(let to of arrObjs)
    //    to.destroy();

    //arrObjs = [];
}

//定时器刷新 函数
function $timerTriggered(interval) {

    //obj.Rectangle = "" || '';
}

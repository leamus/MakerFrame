.pragma library

var waittime = 1000;
var colorchange = `black`;

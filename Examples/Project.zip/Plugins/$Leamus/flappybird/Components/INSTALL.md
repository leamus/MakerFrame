Compile Bacon2D to you target architecture and place the result in the imports/ folder

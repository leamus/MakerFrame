
/*
  组件父对象：
    game.$sys.screen / itemComponentsContainer：固定屏幕上
    game.$sys.scene / game.$sys.scene：会改变大小
    game.$sys.container / itemContainer：会改变大小和随地图移动
*/


//描述
var $description = 'flappy bird';


//可以定义其他变量或函数；游戏中使用 game.$plugins['模块名'] 来调用
//var arrObjs = [];
var obj = null;



//载入 函数
function $load() {
    //console.debug('[Plugins]load：', game.$plugins['Text'].$description, this, this === game.$plugins['Text']);

}

//初始化 函数
function $init() {
    console.debug('[Plugins]init');

    if(obj)
        obj.visible = true;

    //for(let to of arrObjs)
    //    to.visible = true;
}

//释放 函数
function $release() {
    console.debug('[Plugins]release');

    if(obj)
        obj.visible = false;

    //for(let to of arrObjs)
    //    to.visible = false;
}

//卸载 函数
function $unload() {
    console.debug('[Plugins]unload');

    if(obj)
        obj.destroy();
    obj = null;

    //for(let to of arrObjs)
    //    to.destroy();

    //arrObjs = [];
}

//定时器刷新 函数
function $timerTriggered(interval) {
    //obj.text = game.gd['testPlugins'] || '';
}



function show() {

    var comp = Qt.createComponent("main.qml");
    //console.debug(comp)
    if (comp.status === Component.Ready) {
        obj = comp.createObject(game.$sys.scene);
        //arrObjs.push(obj);
    }

}

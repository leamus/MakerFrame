.pragma library

var 配置 = 666;

var moneyName = '银两';

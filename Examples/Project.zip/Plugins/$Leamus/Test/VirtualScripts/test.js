let data = (function() {

    let groupInfo =
        [
         '我的指令',        //组名
         'lightyellow'     //颜色
        ];

    let commandInfos = [
        {
            //命令信息
            command: ['模块名',    //按钮显示的名字
                    '字符串模板%1',    //会对参数进行替换后转换为代码，参数 为%n （n为1开始，分别对应params的每一个参数）；
                    '说明',
                    4,      //缩进空格个数（最好为4的倍数）
                    true,   //是否编译时换行
                    'red',  //代码颜色
                    'white',//按钮颜色
                    []],    //连用命令列表（会加入其他命令）
            //参数信息
            params: [
                //第一个参数
                ['说明',
                 'string',  //输入类型（string、number、bool、string|number、name、code、json）
                 true,  //是否必须
                 0,     //输入类型：0表示默认值，1表示选择某目录下的文件夹，2为数组（预选项，9为固定值
                 '默认值', //输入参数
                 'green'    //显示颜色
                ],

                //第二个参数，label为显示文字帮助
                ['载入一张地图', 'label'],
            ],
        },



        // 载入地图 示例
        {
            command: ['载入地图', 'game.loadmap(%1);', '载入一张地图', 0, true, 'red', 'white'],
            params: [
                ['*@地图名', 'string', true, 1, GameMakerGlobal.config.strProjectPath + GameMakerGlobal.config.separator + GameMakerGlobal.config.strCurrentProjectName + GameMakerGlobal.config.separator + GameMakerGlobal.config.strMapDirName + GameMakerGlobal.config.separator, 'green'],
                ['载入一张地图', 'label'],
            ],
        },

        //显示信息示例
        {
            command: ['显示信息', 'yield game.msg(%1,%2,%3,%4,%5);', '', 0, true, 'red', 'white'],
            params: [
                ['*@信息', 'string', true, 2, [['文字', '变量', '地图变量', '全局变量'], ['内容', '${变量1}', '${game.d["变量1"]}', '${game.gd["变量1"]}']], 'green'],
                ['文字间隔', 'number', '60', 0, '60', 'blue'],
                ['预定义文字', 'string', '``', 0, '', 'lightblue'],
                ['持续时间', 'number', '1000', 0, '', 'lightblue'],
                ['显示效果', 'number', '3', 2, [['固定大小', '自适应高度', '自适应宽度', '自适应宽高'], ['0', '2', '1', '3'], '3'], 'lightblue'],
                //['是否暂停游戏', 'bool', 'true', 0, '', 'darkblue'],
            ],
        },
    ];



    return {groupInfo, commandInfos};

})();

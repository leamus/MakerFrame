//.pragma library

//导入配置文件
//.import 'Config.js' as Config

//导入qml组件
.import QtQml 2.14 as QtQml



/*
  组件父对象：
    game.$sys.screen / itemComponentsContainer：固定屏幕上
    game.$sys.scene / game.$sys.scene：会改变大小
    game.$sys.container / itemContainer：会改变大小和随地图移动
*/



//自定义 全局定义变量和函数
//  所有可以写脚本的地方都可以访问到
//  格式：game.$plugins['模块名'].xxx

//描述
var $description = '系统菜单';


//var arrObjs = [];
var obj = null;

//可以做一些函数给外部调用
function show(callback=null) {
    obj.init();
}
function hide() {
    obj.hide();
}


//载入 函数（游戏第一次运行时会执行，所以在这里创建组件）
function $load() {
    //console.debug('[Plugins]load：', game.$plugins['Text'].$description, this, this === game.$plugins['Text']);

    //载入组件（Comp.qml）
    var comp = Qt.createComponent("GameSystemWindow.qml");
    //console.debug(comp)
    function statusChanged() {
        if (comp.status === QtQml.Component.Ready) {
            //创建组件对象
            obj = comp.createObject(game.$sys.screen);
            //arrObjs.push(obj);
        }
        else if (comp.status === QtQml.Component.Error) {
            console.error(comp.errorString());
        }
    }
    if(comp.status === QtQml.Component.Loading)
        comp.statusChanged.connect(statusChanged);
    else
        statusChanged();

    //console.debug(Config.配置);
}

//初始化 函数（游戏运行 或 读取存档 会运行，用来初始化）
function $init() {
    console.debug('[Plugins]init');

    //if(obj)
    //    obj.visible = true;

    //for(let to of arrObjs)
    //    to.visible = true;
}

//释放 函数（读取存档 或 退出游戏时会执行，用来清理工作）
function $release() {
    console.debug('[Plugins]release');

    //if(obj)
    //    obj.visible = false;

    //for(let to of arrObjs)
    //    to.visible = false;
}

//卸载 函数（读取存档 或 退出游戏时会执行，用来删除组件）
function $unload() {
    console.debug('[Plugins]unload');

    //删除组件
    if(obj)
        obj.destroy();
    obj = null;

    //for(let to of arrObjs)
    //    to.destroy();

    //arrObjs = [];
}

//定时器刷新 函数（刷新组件状态）
function $timerTriggered(interval) {
    //if(game.gd['$sys_money'])
    //    obj.text = game.gd['$sys_money'] + Config.moneyName;
    //else
    //    obj.text = '你没钱';
}

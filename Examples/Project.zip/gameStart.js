//evaluateFilePath：注入到全局的 本js入口文件 路径，有需要的话得保存到闭包中
console.debug("[gameStart]evaluateFilePath:", evaluateFilePath);

//运行js文件，第二个参数为文件路径，缺省为本文件的路径。
//注意：evaluateFilePath不会随着evaluateFile运行的JS文件路径而改变，所有从此文件入口执行的js文件的evaluateFilePath路径都是本JS文件所在路径!!
//let v = game.evaluateFile("gameConfig3.js");
///var v2 = 999;   //会污染全局环境（globalObject）
//或 game.evaluateFile("gameConfig3.js", evaluateFilePath);

//推荐写法
(function(){
    //这里可以定义闭包变量
    let thisFilePath = evaluateFilePath;



    //正式脚本内容
    //也可以直接返回函数（如果不需要yield）或Generator对象（如果不需要参数）

    //游戏开始脚本
    return (function*() {



    //var Pleafles = 999;
    //let Leamus = 999;

    let v = game.evaluateFile("gameConfig3.js", thisFilePath);  //这里必须提供第二个参数，否则值不确定


    while(1) {
        let c = yield game.menu("请选择", ["开始游戏","读取存档","游戏说明","制作人员"]);
        switch(c) {
            case 0:
                game.loadmap('榆林一中');
                game.scale(1);
                game.createhero('美奈子',"美奈子");
                game.setmap(8,17);
                game.playmusic("轻音乐1");

                yield game.msg("欢迎来到鹰歌Maker", 0);
                c = yield game.menu("请选择性别", ["男","女","人妖","未知"]);
                yield game.msg("你的性别是：" + ["男","女","人妖","未知"][c], 0);

                break;
            case 1:
                /*let arrSave = [];
                for(let i = 0; i < 3; ++i) {
                    let ts = game.checksave('存档' + i);
                    if(ts) {
                        arrSave.push('存档%1：%2（%3）'.arg(i).arg(ts.Name).arg(ts.Time));
                    }
                    else
                        arrSave.push('空');
                }*/

                let arrSave = game.makerJS.readSavesInfo();

                c = yield game.menu("载入存档", [...arrSave,"自动存档","取消"]);
                switch(c) {
                    case 0:
                    case 1:
                    case 2:
                        //game.globalLibraryJS.setTimeout(function() {game.load('存档' + c)}, 0, game);
                        if(game.load('存档' + c))
                            break;
                        else
                            yield game.msg("读取失败");
                        continue;
                    case 3:
                        //game.globalLibraryJS.setTimeout(function() {game.load('autosave')}, 0, game);
                        if(game.load('autosave'))
                            break;
                        else
                            yield game.msg("读取失败");
                        continue;
                    default:
                        continue;
                }

                break;
            case 2:
                yield game.msg("仅供测试功能");
                continue;
            case 3:
                yield game.msg("框架引擎开发：深林孤鹰；游戏开发：荔竹");
                continue;
        }
        break;
    }



})})();

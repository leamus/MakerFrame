//def();
console.debug("!!evaluateFilePath:", evaluateFilePath);

game.evaluateFile("gameConfig3.js");

(function*() {
    //abc();
    game.loadmap('榆林一中');
    game.scale(1);
    game.createhero('美奈子',"美奈子");
    game.setmap(8,17);
    game.playmusic("轻音乐1");
    if(!game.load("autosave"))
        yield game.msg("欢迎来到鹰歌Maker");
    let c = yield game.menu("请选择性别", ["男","女","人妖","未知"]);
    yield game.msg("你的性别是：" + ["男","女","人妖","未知"][c]);
}
)

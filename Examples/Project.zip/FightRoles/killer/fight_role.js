
//闭包写法
let data = (function() {



    //独立属性，用 combatant 来引用；会保存到存档中；
    //params：使用对象{RId:xxx, Params: 。。。}创建时的对象参数。
    let $createData = function(params) { //创建战斗角色时的初始数据，可忽略（在战斗脚本中写）；
        return {
            //$name: '敌人1', $properties: {HP: [60,60,60]}, $avatar: '', $size: [60, 60], $color: 'white', $skills: [{RId: 'fight'}], $goods: [], $equipment: [], $money: 6, $EXP: 6,
            $avatar: 'avatar.png',
        };
    };


    //公用属性，用 combatant.$commons 或 combatant 来引用；
    let $commons = {

        //$name: '敌人1', $properties: {HP: [60,60,60]}, $avatar: '', $size: [60, 60], $color: 'white', $skills: [{RId: 'fight'}], $goods: [], $equipment: [], $money: 6, $EXP: 6,
        //$avatar: 'avatar.png',


        //动作包含的 精灵名
        $actions: function(combatant) {
            return {
                'Normal': 'killer_normal',
                'Kill': 'killer_kill',
            };
        }


        //角色单独的升级链脚本和升级算法，可忽略（会自动使用通用的升级链和算法）

        /*
        //角色单独的升级链脚本
        function *levelUpScript(combatant) {
        }

        //targetLeve级别对应需要达到的 各项属性 的算法（升级时会设置，可选；注意：只增不减）
        function levelAlgorithm(combatant, targetLevel) {
            if(targetLevel <= 0)
                return 0;

            let level = 1;  //级别
            let exp = 10;   //级别的经验

            while(level < targetLevel) {
                exp = exp * 2;
                ++level;
            }
            return {EXP: exp};
        }
        */
    };



    return {$createData, $commons};

})();

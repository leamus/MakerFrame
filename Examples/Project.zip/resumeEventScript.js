//evaluateFilePath：注入到全局的 本js入口文件 路径，有需要的话得保存到闭包中
console.debug("[resumeEventScript]evaluateFilePath:", evaluateFilePath);

//运行js文件，第二个参数为文件路径，缺省为本文件的路径。
//注意：evaluateFilePath不会随着evaluateFile运行的JS文件路径而改变，所有从此文件入口执行的js文件的evaluateFilePath路径都是本JS文件所在路径!!
//let v = game.evaluateFile("gameConfig3.js");
///var v2 = 999;   //会污染全局环境（globalObject）
//或 game.evaluateFile("gameConfig3.js", evaluateFilePath);

//推荐写法
(function(){
    //这里可以定义闭包变量
    let thisFilePath = evaluateFilePath;



    //正式脚本内容
    //也可以直接返回函数（如果不需要yield）或Generator对象（如果不需要参数）

    //恢复算法
    return (function resumeEventScript(hero) {

        if(hero.remainHP === 0)
            return;

        hero.remainHP += 10;
        if(hero.remainHP > hero.healthHP)
            hero.remainHP = hero.healthHP;

        hero.remainMP += 10;
        if(hero.remainMP > hero.MP)
            hero.remainMP = hero.MP;



})})();

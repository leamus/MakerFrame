
//闭包写法
let data = (function(){



//独立属性，用 goods 来引用；会保存到存档中；
//params：使用对象{RId:xxx, Params: 。。。}创建道具时的对象参数。
let $createData = function(params) {

    let imagePath = game.$global.toQMLPath(game.$gameMakerGlobal.imageResourceURL('goods.jpg'));

    return {
        //游戏中显示的 名称和描述
        $name: '西瓜刀',
        $description: `${game.$globalLibraryJS.showRichTextImage(imagePath, 100, 100)} 这是一把能用来杀猪的西瓜刀，攻击+50，魅力-100`,

        $price: [200, 100],	//买卖金额，false表示不能买卖
        $type: 1,	//1为装备；2为普通使用；3为战斗使用；4为剧情类
        $position: "武器",	//装备位置；武器是特殊位置，普通攻击时会使用 武器 的 skills
        $skills: [{RId: '全体攻击'}],	//道具带的技能（此时道具作为装备，且为 武器 时可用）
        $stackable: true,    //是否可叠加（注意：如果做 随机属性的道具，则最好设置为false，表示每个道具都是单独的，不会叠加）

        $fight: [{RId: '全体攻击'}],    //战斗中点 使用 的 对应触发的技能（可以不用技能，只用脚本）

        $color: '', //文字颜色
        $image: 'goods.jpg', //图片相对路径（相对于Resources/Images路径，../../表示项目根路径）
        $size: [50, 50],    //图像大小

        行走速度: 0.3,
    };
};



//公用属性，用 goods.$commons 来引用；
let $commons = {

    //使用脚本
    $useScript: function *(goods, combatant) {
        if(combatant === undefined || combatant === null)
            combatant = yield game.menu('选择角色', game.fighthero(-1, 0), true);	//选择角色

        game.addprops(combatant, {attack: 1});

        yield game.msg("你用西瓜刀切了两片西瓜开始吆喝：好甜的西瓜啊，一斤2块5啦", 50);
        //console.debug(goods.$rid, combatant);

        game.removegoods(goods, 1);	//背包道具-1
        return -1;
    },
    //这样写不会显示 使用 选项
    //$useScript: null,


    //装备效果
    //  注意：$$propertiesWithExtra为临时增加，$properties为永久增加，所以可以用$properties作为参考，来修改$$propertiesWithExtra）；
    $equipEffectAlgorithm: function(goods, combatant) {
        combatant.$$propertiesWithExtra.attack += 50;
    },
    //$equipEffectAlgorithm: null,

    //装备脚本
    $equipScript: function*(goods, combatant) {
        if(combatant === undefined || combatant === null)
            combatant = yield game.menu('选择角色', game.fighthero(-1, 0), true);	//选择角色
        game.getgoods(game.unload(combatant, goods.$position));	//脱下装备并放入背包
        game.equip(combatant, goods);	//装备；使用 goods 的 position 属性来装备；
        game.removegoods(goods, 1);	//背包道具-1

        yield game.msg("西瓜刀在手，打遍天下无敌手");
        //console.debug(goods, c);
    },
    //这样写不会显示 装备 选项
    //$equipScript: null,


    //战斗时使用脚本；数组内容分别是：0，检测是否可用；1，收尾代码；
    $fightScript: [
        //选择道具时脚本
        function *$choiceScript(goods, combatant) {
            return;
        },
        //是否可用
        function $check(goods, combatant, stage){
            return true;
        },
        //收尾代码
        function *$overScript(goods, combatant){
            game.removegoods(goods, 1);	//背包道具-1
            return;
        },
    ],
    //这样写不会显示 战时 选项
    //$fightScript: null,
};



return ({$createData, $commons});

})();

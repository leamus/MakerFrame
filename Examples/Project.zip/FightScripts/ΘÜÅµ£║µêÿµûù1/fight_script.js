
//闭包写法
let data = (function() {



    //独立属性，用 fightData 来引用；
    let $createData = function(params) {
        return {
            //背景图
            $backgroundImage: 'FightScene1.jpg',
            //播放音乐名，为true表示继续播放当前地图的音乐
            $music: 'fight.mp3',
            //是否可以逃跑；true则调用 通用逃跑算法；0~1则为概率逃跑；false为不能逃跑
            $runAway: 1,
            $enemyCount: [1,1],	//为数组（m-n）的随机排列，为数字则依次按顺序排列，如果为true则表示按顺序排列
            //RId是战斗角色资源名（必写），$goods是携带道具（可掉落），其他属性会覆盖战斗角色属性
            $enemiesData: [
                {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '西瓜刀', Params: {}}], $equipment: ['可视化道具'], $money: 5, $EXP: 5},
                {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '小刀', Params: {}}], $equipment: ['可视化道具'], $money: 10, $EXP: 10},
                {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '小草', Params: {}}], $equipment: ['可视化道具'], $money: 20, $EXP: 20},
                {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['小草'], $equipment: ['可视化道具'], $money: 50, $EXP: 50},
                {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $equipment: ['可视化道具'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $equipment: ['可视化道具'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $equipment: ['可视化道具'], $money: 100, $EXP: 100},

                /*
                {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: ['巴掌'], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
                {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: ['巴掌'], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
                {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
                {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['小草'], $money: 50, $EXP: 50},
                {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},

                {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
                {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
                {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
                {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight'], $goods: ['小草'], $money: 50, $EXP: 50},
                {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                */
            ],
        }
    };


    //公用属性，用 fightData.$commons 或 fightData 来引用；
    let $commons = {

        /*
        //背景图
        $backgroundImage: 'FightScene1.jpg',
        //播放音乐名，为true表示继续播放当前地图的音乐
        $music: 'fight.mp3',
        //是否可以逃跑；true则调用 通用逃跑算法；0~1则为概率逃跑；false为不能逃跑
        $runAway: 1,
        $enemyCount: [1,3],	//为数组（m-n）的随机排列，为数字则依次按顺序排列，如果为true则表示按顺序排列
        //RId是战斗角色资源名（必写），$goods是携带道具（可掉落），其他属性会覆盖战斗角色属性
        $enemiesData: [
            {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
            {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
            {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}, '巴掌', '恢复血量'], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
            {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['小草'], $money: 50, $EXP: 50},
            {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight', '巴掌', '恢复血量'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
        ],
        */


        $fightInitScript: function *(teams, fightData) {
            //选择上场战斗人物代码

            //我方最多上场人数
            let maxCount = -1;
            //临时存放到myCombatants
            let myCombatants = [...teams[0]];
            teams[0].length = 0;
            //循环选择
            while(1) {
                //选择列表
                let arrList = [];
                if(teams[0].length === 0)
                    arrList.push('全部');
                else
                    arrList.push('取消');
                //剩下的每个名字
                for(let tc of myCombatants) {
                    arrList.push(tc.$name);
                }
                let c = yield fight.menu('请选择战斗角色', arrList);
                //选择全部 或 取消
                if(c === 0) {
                    //全部
                    if(teams[0].length === 0) {
                        if(maxCount <= 0)
                            teams[0].push(...myCombatants);
                        else
                            teams[0].push(...myCombatants.splice(0, maxCount));
                    }
                    break;
                }
                else {
                    teams[0].push(...myCombatants.splice(c - 1, 1));
                }
                //选空了
                if(myCombatants.length === 0)
                    break;
                if(maxCount > 0 && teams[0].length >= maxCount)
                    break;
            }

            yield fight.msg('战斗初始化事件2', 0);
        },

        $fightStartScript: function *(teams, fightData) {
            yield fight.msg('战斗开始事件');
        },

        $fightRoundScript: function *(round, step, teams, fightData) {
            switch(step) {  //step：0，回合开始；1，选择完毕
            case 0:
                yield fight.msg('第%1回合'.arg(round));
                break;
            case 1:
                break;
            }
        },

        $fightEndScript: function *(r, step, teams, fightData) {
            //step：为0是战斗结束时调用；为1时返回地图时调用
            //r中包含：result（战斗结果）、money和exp
            //  这里可以修改r，然后会传递给 通用战斗结束函数
            //console.debug(JSON.stringify(r));
            //r.result = 666;

            switch(step) {
            case 0:
                yield fight.msg('战斗结束事件：' + r.result);
                break;
            case 1:
                yield game.msg('返回地图事件');
                break;
            }
        },
    };



    return {$createData, $commons};

})();

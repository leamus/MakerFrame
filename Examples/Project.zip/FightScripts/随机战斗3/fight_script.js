
//闭包写法
let data = (function() {



    //独立属性，用 fightData 来引用；
    let $createData = function(params) {
        return {
            //背景图
            $backgroundImage: 'FightScene2.jpg',
            $music: 'fight.mp3',
            //是否可以逃跑；true则调用 通用逃跑算法；0~1则为概率逃跑；false为不能逃跑
            $runAway: true,
            $enemyCount: [1, 3],	//为数组（m-n）的随机排列，为数字则依次按顺序排列，如果为true则表示按顺序排列
            //RId是战斗角色资源名（必写），$goods是携带道具（可掉落），其他属性会覆盖战斗角色属性
            $enemiesData: [
                {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
                {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
                {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
                {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight'], $goods: ['小草'], $money: 50, $EXP: 50},
                {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            ],
        }
    };


    //公用属性，用 fightData.$commons 来引用；
    let $commons = {
        $fightRoundScript: function *(round, step, teams, fightData) {
            switch(step) {  //step：0，回合开始；1，选择完毕
            case 0:
                game.$globalLibraryJS.setTimeout(function() {
                        //自动重复上次类型，也可以根据需要改写
                        for(let i = 0; i < fight.myCombatants.length; ++i) {
                            //if(repeaterMyCombatants.itemAt(i).opacity !== 0) {
                            if(fight.myCombatants[i].$properties.HP[0] > 0) {
                                fight.myCombatants[i].$$fightData.$target = fight.myCombatants[i].$$fightData.$lastTarget;
                                //fight.myCombatants[i].$$fightData.$attackSkill = fight.myCombatants[i].$$fightData.$info.lastAttackSkill;
                                fight.myCombatants[i].$$fightData.$choiceType = fight.myCombatants[i].$$fightData.$lastChoiceType;
                            }
                        }
                        fight.continueFight();
                    },0,root
                );

                break;
            case 1:
                break;
            }
        },

        $fightStartScript: function *(teams, fightData) {
            yield fight.msg('战斗开始事件');
        },

        $fightEndScript: function *(r, teams, fightData) {
            //这里可以修改r，然后会传递给 通用战斗结束函数
            //r中包含：result（战斗结果）、money和exp

            yield fight.msg('战斗结束事件：' + r.result);
            //console.debug(JSON.stringify(r));
            //r.result = 666;
            game.run(function*(){
                yield fight.msg('返回地图事件');
            });
        },
    };



    return {$createData, $commons};

})();


//闭包写法
let data = (function() {



    //独立属性，用 fightData 来引用；
    let $createData = function(params) {
        return {
            //背景图
            $backgroundImage: 'FightScene2.jpg',
            $music: 'fight.mp3',
            //是否可以逃跑；true则调用 通用逃跑算法；0~1则为概率逃跑；false为不能逃跑
            $runAway: true,
            $enemyCount: [1, 7],	//为数组（m-n）的随机排列，为数字则依次按顺序排列，如果为true则表示按顺序排列
            //RId是战斗角色资源名（必写），$goods是携带道具（可掉落），其他属性会覆盖战斗角色属性
            $enemiesData: [
                {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
                {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
                {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
                {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight'], $goods: ['小草'], $money: 50, $EXP: 50},
                {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
                {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            ],
        }
    };


    //公用属性，用 fightData.$commons 或 fightData 来引用；
    let $commons = {

        /*
        //背景图
        $backgroundImage: 'FightScene2.jpg',
        $music: 'fight.mp3',
        //是否可以逃跑；true则调用 通用逃跑算法；0~1则为概率逃跑；false为不能逃跑
        $runAway: true,
        $enemyCount: [1, 7],	//为数组（m-n）的随机排列，为数字则依次按顺序排列，如果为true则表示按顺序排列
        //RId是战斗角色资源名（必写），$goods是携带道具（可掉落），其他属性会覆盖战斗角色属性
        $enemiesData: [
            {RId: 'killer2', $name: '敌人1', $properties: {HP: [5, 5, 5], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '西瓜刀', Params: {}}], $money: 5, $EXP: 5},
            {RId: 'killer2', $name: '敌人2', $properties: {HP: [10, 10, 10], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小刀', Params: {}}], $money: 10, $EXP: 10},
            {RId: 'killer2', $name: '敌人3', $properties: {HP: [20, 20, 20], speed: 1}, $skills: [{RId: 'fight', Params: {}}], $goods: [{RId: '小草', Params: {}}], $money: 20, $EXP: 20},
            {RId: 'killer2', $name: '敌人4', $properties: {HP: [50, 50, 50], speed: 1}, $skills: ['fight'], $goods: ['小草'], $money: 50, $EXP: 50},
            {RId: 'killer2', $name: '敌人5', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            {RId: 'killer2', $name: '敌人6', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
            {RId: 'killer2', $name: '敌人7', $properties: {HP: [100, 100, 100], speed: 1}, $skills: ['fight'], $goods: ['西瓜刀'], $money: 100, $EXP: 100},
        ],
        */


        FightInitScript: function *(teams, fightData) {
            //yield fight.msg('战斗初始化事件', 0);
        },

        FightStartScript: function *(teams, fightData) {
            yield fight.msg('战斗开始事件');
        },

        FightRoundScript: function *(round, step, teams, fightData) {
            switch(step) {  //step：0，回合开始；1，选择完毕
            case 0:
                yield fight.msg('第%1回合'.arg(round));
                break;
            case 1:
                break;
            }
        },

        FightEndScript: function *(r, step, teams, fightData) {
            //step：为0是战斗结束时调用；为1时返回地图时调用
            //r中包含：result（战斗结果）、money和exp
            //  这里可以修改r，然后会传递给 通用战斗结束函数
            //console.debug(JSON.stringify(r));
            //r.result = 666;

            switch(step) {
            case 0:
                yield fight.msg('战斗结束事件：' + r.result);
                break;
            case 1:
                yield fight.msg('返回地图事件');
                break;
            }
        },
    };



    return {$createData, $commons};

})();

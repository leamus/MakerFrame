//鹰：可以包含其他文件：
//.import 'XXX.js' as JsName
//console.debug(JsName.aaa);
//console.debug(buttonA)

/*var objType = Create.createObject();
objType.setName('Rectangle');
var p = {width: 50, height: 50, color: '#FFFFFFFF'}
var obj = objType.createObject(buttonA,p);
*/



//游戏开始脚本（开始时调用）
function *$start() {

    game.playmusic("start.mp3");


    while(1) {
        let c = yield game.menu("请选择", ["开始游戏","读取存档","游戏说明","制作人员",'插件小游戏1','插件小游戏2']);
        switch(c) {
            case 0:
                game.scale(1);
                game.setinterval(16);
                game.loadmap('榆林一中');
                game.createhero('美奈子');
                game.movehero(8,17);
                game.playmusic("轻音乐1.mp3");

                yield game.msg("欢迎来到鹰歌Maker", 0);
                c = yield game.menu("请选择性别", ["男","女","人妖","未知"]);
                yield game.msg("你的性别是：" + ["男","女","人妖","未知"][c], 0);

                break;
            case 1:
                /*let arrSave = [];
                for(let i = 0; i < 3; ++i) {
                    let ts = game.checksave('存档' + i);
                    if(ts) {
                        arrSave.push('存档%1：%2（%3）'.arg(i).arg(ts.Name).arg(ts.Time));
                    }
                    else
                        arrSave.push('空');
                }*/

                let readSavesInfo = game.$userscripts.$readSavesInfo || game.$gameMakerGlobalJS.$readSavesInfo;
                let arrSave = readSavesInfo();

                c = yield game.menu("载入存档", [...arrSave,"自动存档","取消"]);
                switch(c) {
                    case 0:
                    case 1:
                    case 2:
                        //game.$globalLibraryJS.setTimeout(function() {game.load('存档' + c)}, 0, game);
                        if(game.load('存档' + c))
                            break;
                        else
                            yield game.msg("读取失败");
                        continue;
                    case 3:
                        //game.$globalLibraryJS.setTimeout(function() {game.load('autosave')}, 0, game);
                        if(game.load('autosave'))
                            break;
                        else
                            yield game.msg("读取失败");
                        continue;
                    default:
                        continue;
                }
                break;
            case 2:
                yield game.msg("仅供测试框架功能");
                yield game.msg("首先和右上角人物对话，获得战斗英雄和技能，然后可以和中间两人物斗殴（一个人少一个人多），左上角人物可以交易", 10);
                continue;
            case 3:
                yield game.msg("框架和引擎开发：深林孤鹰；DEMO开发：荔竹", 60, '', 0);
                continue;
            case 4:
                game.stopmusic();
                game.$plugins['$Leamus']['maroon'].show();
                return;
            case 5:
                game.stopmusic();
                game.$plugins['$Leamus']['samegame'].show();
                return;
        }

        break;
    }

}


//游戏初始化（游戏开始和载入存档时调用）
function *$init() {

    //每秒恢复
    function resumeEventScript(combatant) {

        if(combatant.$properties.HP[0] <= 0)
            return;

        game.addprops(combatant, {'HP': [2], 'MP': [2]});
    }

    //每秒恢复事件
    game.addtimer("resume_event", 1000, -1, true);
    game.gf["resume_event"] = function() {
        for(let h in game.gd["$sys_fight_heros"]) {
            resumeEventScript(game.gd["$sys_fight_heros"][h]);
        }
    }


    //点击屏幕事件
    game.gf['$map_click'] = function(bx, by, x, y) {
        let hero = game.hero(0, {$action: 2, $targetBx: bx, $targetBy: by});
    }


    yield game.msg("合理安排时间");

    game.goon();

}


//存档后调用
function $save() {
    game.gd['save_datetime'] = Date.now();
    //console.warn('save!!!')
}


//读档后调用
function $load() {
    game.run(function*() { 
        yield game.msg('读档');
    })
}

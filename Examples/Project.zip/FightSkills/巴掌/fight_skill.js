
//闭包写法
let data = (function() {



    //独立属性，用 skill 来引用；
    let $createData = function(params) {
        return {
            $name: '巴掌',
            $description: '上去扇对方两巴掌，并随机给与毒乱封眠状态',

            //0：普通攻击；1：技能
            $type: 1,
            //0b10为选对方；0b1为选己方；0为不选（全体技能）
            $targetFlag: 0b10,
            //选择目标数；-1为全体；>0为个数；数组为范围；
            $targetCount: 1,
        };
    };


    //公用属性，用 skill.$commons 来引用；
    let $commons = {
        //选择技能时脚本
        $choiceScript: function *(skill, combatant) {
            return;
        },

        //技能产生的效果 和 动画
        $playScript: function*(skill, combatant) {

            //使用的技能对象（可以用技能的数据）
            //let skill = combatant.$$fightData.$attackSkill;
            //目标战斗人物
            let targetCombatant = combatant.$$fightData.$target[0];

            //这里是计算方法
            let SkillEffectResult;
            let harm;


            //let killCount = game.rnd(1,3);


            //Normal 动作特效，无限循环动画、500ms结束、对方面前
            //yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500, Run: 1});
            //kill 动作特效，1次，等待播放结束
            yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1});
            //kill 特效，1次，等待播放结束，对方位置，特效ID
            SkillEffectResult = yield ({Type: 3, Target: targetCombatant, Params: {Skill: 1}});
            harm = SkillEffectResult.shift().HP;
            game.addprops(targetCombatant, {'HP': [-harm[0], -harm[1]]});
            yield ({Type: 1});
            yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatant, Position: undefined});

            yield ({Type: 20, Name: '石头', Loops: 1, Interval: 200, RId: 'kill1', Combatant: targetCombatant, Position: 1});
            SkillEffectResult = yield ({Type: 3, Target: targetCombatant, Params: {Skill: 1}});
            harm = SkillEffectResult.shift().HP;
            game.addprops(targetCombatant, {'HP': [-harm[0], -harm[1]]});
            yield ({Type: 1});
            yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatant, Position: undefined});

            yield ({Type: 20, Name: 'kill', Loops: 1, Interval: 200, RId: 'kill2', Combatant: targetCombatant, Position: 1});
            SkillEffectResult = yield ({Type: 3, Target: targetCombatant, Params: {Skill: 1}});
            harm = SkillEffectResult.shift().HP;
            game.addprops(targetCombatant, {'HP': [-harm[0], -harm[1]]});
            yield ({Type: 1});
            yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatant, Position: undefined});

            yield ({Type: 20, Name: '骷髅', Loops: 1, Interval: -1, RId: 'kill3', Combatant: targetCombatant, Position: 1});
            /*/如果砍2次
            if(killCount > 1)  {
                //效果结算，Skill：KillType：
                SkillEffectResult = yield ({Type: 1, Params: {Skill: 1}});

                //显示文字，同步播放、对方位置、红色、内容、大小
                yield ({Type: 30, Interval: 0, Color: 'red', Text: -SkillEffectResult.shift().value, FontSize: 20, Combatant: targetCombatant, Position: undefined});


                //再杀一次
                yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1});
                yield ({Type: 20, Name: 'Kill', Loops: 1, Interval: 0, RId: 'Kill2', Combatant: targetCombatant, Position: 1});
            }
            */


            //随机Buff
            let buffCode = game.rnd(1, 5);
            switch(buffCode) {
            case 1:
                game.$userscripts.getBuff(targetCombatant, buffCode, {BuffName: '毒', Round: game.rnd(1, 4), HarmType: 1, HarmValue: 10});
                yield ({Type: 30, Interval: 0, Color: 'green', Text: '毒', FontSize: 20, Combatant: targetCombatant, Position: undefined});
                break;
            case 2:
                game.$userscripts.getBuff(targetCombatant, buffCode, {BuffName: '乱', Round: game.rnd(1, 4)});
                yield ({Type: 30, Interval: 0, Color: 'orange', Text: '乱', FontSize: 20, Combatant: targetCombatant, Position: undefined});
                break;
            case 3:
                game.$userscripts.getBuff(targetCombatant, buffCode, {BuffName: '封', Round: game.rnd(1, 4)});
                yield ({Type: 30, Interval: 0, Color: 'yellow', Text: '封', FontSize: 20, Combatant: targetCombatant, Position: undefined});
                break;
            case 4:
                game.$userscripts.getBuff(targetCombatant, buffCode, {BuffName: '眠', Round: game.rnd(1, 4)});
                yield ({Type: 30, Interval: 0, Color: 'blue', Text: '眠', FontSize: 20, Combatant: targetCombatant, Position: undefined});
                break;
            }


            //Normal 动作特效，无限循环动画、500ms结束、原位置
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500});



            //技能结束，必须返回null
            return null;
        },


        //检查技能（有4个阶段会调用：选择时、攻击时、敌人和我方遍历时）；
        //返回：true表示可以使用；字符串表示不能使用并提示的信息（只有选择时）；
        //stage为0表示选择时，为1表示选择后（在阶段1减去MP的作用：道具的技能可以跳过减MP）；
        $check: function(skill, combatant, stage) {
            if(combatant.$properties.MP[0] < 50)
                return '技能点不足';

            //阶段1时减去MP
            if(stage === 1)
                game.addprops(combatant, {'MP': [-50]});

            return true;
        },
    };



    return {$createData, $commons};

})();

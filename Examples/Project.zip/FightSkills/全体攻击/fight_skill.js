
//闭包写法
let data = (function() {



    //独立属性，用 skill 来引用；
    let $createData = function(params) {
        return {
            $name: '全体攻击',
            $description: '打每个人一下',

            //0：普通攻击；1：技能
            $type: 0,
            //0b10为选对方；0b1为选己方；0为不选（全体技能）
            $targetFlag: 0,
            //选择目标数；-1为全体；>0为个数；数组为范围；
            $targetCount: -1,
        };
    };


    //公用属性，用 skill.$commons 来引用；
    let $commons = {
        //选择技能时脚本
        $choiceScript: function *(skill, combatant) {
            return;
        },

        //技能产生的效果 和 动画
        $playScript: function*(skill, combatant) {

            //使用的技能对象（可以用技能的数据）
            //let skill = combatant.$$fightData.$attackSkill;
            //目标战斗人物
            //let targetCombatant = combatant.$$fightData.$target[0];
            let targetCombatants = combatant.$$fightData.$info.$team[1];

            //返回战斗算法结果
            let SkillEffectResult;
            let harm;


            let killCount = game.rnd(1,3);


            //Normal 动作特效，无限循环动画、500ms结束、对方面前
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500, Target: 1, Run: 2});
            //kill 动作特效，1次，等待播放结束
            yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1});


            //每个被攻击显示 kill 特效
            for(let ti in targetCombatants) {
                if(targetCombatants[ti].$properties.HP[0] <= 0)
                    continue;

                //kill 特效，1次，同步播放，对方位置，特效ID
                yield ({Type: 20, Name: 'kill', Loops: 1, Interval: 0, RId: 'kill'+ti, Combatant: targetCombatants[ti], Position: 1});
            }
            //每个被攻击计算并显示伤害
            for(let ti in targetCombatants) {
                if(targetCombatants[ti].$properties.HP[0] <= 0)
                    continue;
                //Params：传递给通用算法的参数
                SkillEffectResult = yield ({Type: 3, Target: targetCombatants[ti], Params: {Skill: 1}});
                harm = SkillEffectResult.shift().HP;
                game.addprops(targetCombatants[ti], {'HP': [-harm[0], -harm[1]]});
                //yield ({Type: 1});
                //显示文字，同步播放、对方位置、红色、内容、大小
                yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatants[ti], Position: undefined});
            }

            //Normal 动作特效，无限循环动画、500ms结束、原位置
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500, Run: 0});



            //技能结束，必须返回null
            return null;
        },


        //检查技能（有4个阶段会调用：选择时、攻击时、敌人和我方遍历时）；
        //返回：true表示可以使用；字符串表示不能使用并提示的信息（只有选择时）；
        //stage为0表示选择时，为1表示选择后（在阶段1减去MP的作用：道具的技能可以跳过减MP）；
        $check: function(skill, combatant, stage) {
            //if(combatant.$properties.MP[0] < 50)
            //    return '技能点不足';

            //阶段1时减去MP
            //if(stage === 1)
            //    game.addprops(combatant, {'MP': [-50]});

            return true;
        },
    };



    return {$createData, $commons};

})();

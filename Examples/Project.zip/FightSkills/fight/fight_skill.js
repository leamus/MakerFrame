
//闭包写法
let data = (function() {



    //独立属性，用 skill 来引用；会保存到存档中；
    let $createData = function(params) {
        return {
            $name: '普通攻击',
            $description: '跑上去打对方一下',

            //0：普通攻击；1：技能
            $type: 0,
            //0b10为选对方；0b1为选己方；0为不选（全体技能）
            $targetFlag: 0b10,
            //选择目标数；-1为全体；>0为个数；数组为范围；
            $targetCount: [1, 1],
        };
    };


    //公用属性，用 skill.$commons 或 skill 来引用；
    let $commons = {

        /*
        $name: '普通攻击',
        $description: '跑上去打对方一下',

        //0：普通攻击；1：技能
        $type: 0,
        //0b10为选对方；0b1为选己方；0为不选（全体技能）
        $targetFlag: 0b10,
        //选择目标数；-1为全体；>0为个数；数组为范围；
        $targetCount: [1, 1],
        */


        //选择技能时脚本
        $choiceScript: function *(skill, combatant) {
            return;
        },

        //技能产生的效果 和 动画
        $playScript: function*(skill, combatant) {

            //使用的技能对象（可以用技能的数据）
            //let skill = combatant.$$fightData.$attackSkill;
            //目标战斗人物
            let targetCombatant = combatant.$$fightData.$target[0];

            //返回战斗算法结果
            let SkillEffectResult;
            let harm;


            let killCount = game.rnd(1,3);


            //Normal 动作特效，无限循环动画、500ms结束、对方面前
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500, Combatant: combatant, Target: targetCombatant, Run: 1});


            //kill 动作特效，1次，等待播放结束
            yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1, Combatant: combatant});
            //kill 特效，1次，等待播放结束，特效ID，对方和位置
            yield ({Type: 20, Name: 'kill', Loops: 1, Interval: 0, RId: 'kill1', Combatant: targetCombatant, Position: 1});
            //效果，Skill：KillType：
            SkillEffectResult = yield ({Type: 3, Target: targetCombatant, Params: {Skill: 1}});
            harm = SkillEffectResult.shift().HP;
            game.addprops(targetCombatant, {'HP': [-harm[0], -harm[1]]});
            //刷新人物信息
            yield ({Type: 1});
            //显示文字，同步播放、红色、内容、大小、对方和位置
            yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatant, Position: undefined});


            //如果砍2次
            if(killCount > 1)  {

                //再杀一次
                yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1, Combatant: combatant, Target: targetCombatant});
                yield ({Type: 20, Name: 'kill', Loops: 1, Interval: 0, RId: 'kill2', Combatant: targetCombatant, Position: 1});

                SkillEffectResult = yield ({Type: 3, Target: targetCombatant, Params: {Skill: 1}});
                harm = SkillEffectResult.shift().HP;
                game.addprops(targetCombatant, {'HP': [-harm[0], -harm[1]]});
                //刷新人物信息
                yield ({Type: 1});

                yield ({Type: 30, Interval: 0, Color: 'red', Text: -harm[0], FontSize: 20, Combatant: targetCombatant, Position: undefined});

            }


            //Normal 动作特效，无限循环动画、500ms结束、原位置
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500, Combatant: combatant, Run: 0});



            //技能结束，必须返回null
            return null;
        },


        //检查技能（有4个阶段会调用：选择时、攻击时、敌人和我方遍历时）；
        //返回：true表示可以使用；字符串表示不能使用并提示的信息（只有选择时）；
        //stage为0表示选择时，为1表示选择后（在阶段1减去MP的作用：道具的技能可以跳过减MP）；
        $check: function(skill, combatant, stage) {
            //if(combatant.$properties.MP[0] < 50)
            //    return '技能点不足';

            //阶段1时减去MP
            //if(stage === 1)
            //    game.addprops(combatant, {'MP': [-50]});

            return true;
        },
    };



    return {$createData, $commons};

})();

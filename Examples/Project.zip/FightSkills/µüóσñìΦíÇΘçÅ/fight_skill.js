
//闭包写法
let data = (function() {



    //独立属性，用 skill 来引用；会保存到存档中；
    let $createData = function(params) {
        return {
            $name: '恢复血量',
            $description: '恢复血量50',

            //0：普通攻击；1：技能
            $type: 1,
            //0b10为选对方；0b1为选己方；0为不选（全体技能）
            $targetFlag: 0b1,
            //选择目标数；-1为全体；>0为个数；数组为范围；
            $targetCount: 1,
        };
    };


    //公用属性，用 skill.$commons 或 skill 来引用；
    let $commons = {

        /*
        $name: '巴掌',
        $description: '上去扇对方两巴掌，并随机给与毒乱封眠状态',

        //0：普通攻击；1：技能
        $type: 1,
        //0b10为选对方；0b1为选己方；0为不选（全体技能）
        $targetFlag: 0b10,
        //选择目标数；-1为全体；>0为个数；数组为范围；
        $targetCount: 1,
        */


        //选择技能时脚本
        $choiceScript: function*(skill, combatant) {
            return;
        },

        //技能产生的效果 和 动画
        $playScript: function*(skill, combatant) {

            //使用的技能对象（可以用技能的数据）
            //let skill = combatant.$$fightData.$attackSkill;
            //目标战斗人物
            let targetCombatant = combatant.$$fightData.$target[0];

            //返回战斗算法结果
            let SkillEffectResult;

            //给目标人物恢复血量
            game.addprops(targetCombatant, {'HP': [50, 20]}, 1, false);

            //kill 动作特效，1次，等待播放结束
            yield ({Type: 10, Name: 'Kill', Loops: 1, Interval: -1});

            yield ({Type: 30, Interval: -1, Color: 'green', Text: '+50', FontSize: 20, Combatant: targetCombatant, Position: undefined});
            yield ({Type: 30, Interval: -1, Color: 'yellow', Text: '+20', FontSize: 20, Combatant: targetCombatant, Position: undefined});

            //Params：传递给通用算法的参数
            //SkillEffectResult = yield ({Type: 0, Params: {Skill: 0}});
            yield ({Type: 1});

            //Normal 动作特效，无限循环动画、500ms结束、原位置
            yield ({Type: 10, Name: 'Normal', Loops: -1, Interval: 500});



            //技能结束，必须返回null
            return null;
        },


        //检查技能（有4个阶段会调用：选择时、攻击时、敌人和我方遍历时）；
        //返回：true表示可以使用；字符串表示不能使用并提示的信息（只有选择时）；
        //stage为0表示选择时，为1表示选择某战斗角色（我方或敌方，此时targetCombatant不为null，其他情况为null），为10表示战斗中（在阶段10减去MP的作用：道具的技能可以跳过减MP）；
        $check: function(skill, combatant, targetCombatant, stage) {
            if(combatant.$properties.MP[0] < 50)
                return '技能点不足';

            //阶段10时减去MP
            if(stage === 10)
                game.addprops(combatant, {'MP': [-50]});

            return true;
        },
    };



    return {$createData, $commons};

})();

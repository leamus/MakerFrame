function *start(){ //地图载入事件 
}


function *$start() {

    game.createrole({RId: "战士", $bx: 6, $by: 8});
    game.createrole({RId: "英雄坛说", $name: "深林孤鹰", $bx: 15, $by: 15, $action: 0, $direction: 2});
    //game.objRoles["深林孤鹰"].changeDirection(2);

    game.createrole("角色1");
    game.moverole("角色1", 15, 18);

    game.createrole({RId: "角色2", $name: "角色2", $bx: 15, $by: 20});
    game.createrole({RId: "荔竹", $name: "荔竹", $bx: 16, $by: 6});

    yield game.msg("榆林一中");



    game.f["角色2"]=()=>{game.fighting("随机战斗2");}
    game.f["角色1"]=()=>{game.fighting("随机战斗1");}
    game.f["战士"]=function(){
        game.trade(['小刀', '西瓜刀', '零食', ], true, function*(){game.say('战士', '欢迎下次再来');});
    }
    game.f["荔竹"]=`
    if(!game.gd.战斗准备){
    yield game.msg("你学会了【普通攻击】和【巴掌】技能", 10);
    game.createfighthero("killer");
    game.getskill(0, "fight", 0);
    game.getskill(0, "巴掌", -1);
    game.gd.战斗准备 = true;
    }
    else
    game.say('荔竹', '你已经可以战斗了');
    `;
    game.f["$荔竹_collide"]=function(self, role, keep) {
        if(!keep)
            game.say('荔竹', role.$data.$name + '碰了我');
    }

    game.d.深林孤鹰say = 0;

    game.addtimer("$sys_resume_timer", 1000, -1);
    game.f["$sys_resume_timer"] = function() {
        if(game.rnd(1,5) === 1) {
            game.say('角色1', '来砍我呀');
        }
        if(game.rnd(1,6) === 1) {
            game.say('角色2', '来砍我呀，我人多！');
        }
        if(game.rnd(1,7) === 1) {
            game.say('战士', '来买东西哦，价格公道，童叟无欺！');
        }

        if(game.d.深林孤鹰say === 0)
            game.say('深林孤鹰', '我是深林孤鹰');
        if(game.d.深林孤鹰say === 1)
            game.say('深林孤鹰', '唧唧复唧唧');
        if(game.d.深林孤鹰say === 2)
            game.say('深林孤鹰', '木兰当户织');
        if(game.d.深林孤鹰say === 3)
            game.say('深林孤鹰', '不闻机杼声');
        if(game.d.深林孤鹰say === 4)
            game.say('深林孤鹰', '唯闻女叹息');
        game.d.深林孤鹰say = (game.d.深林孤鹰say + 1) % 5;
    }
}

function *$深林孤鹰_click() {
    yield game.msg('点击事件');
}

function*深林孤鹰() {
    yield game.talk("深林孤鹰", "我是深林孤鹰", 30);
    yield game.talk("深林孤鹰", "我好辛苦啊", 30);
    game.say("深林孤鹰", "请多多支持！");
}

function *进入门卫房间() {
    game.loadmap("门房");
    game.movehero(5,10);
}


function *进入食堂() {
    game.loadmap("食堂");
    game.movehero(5,10);
}

function *进教师办公室() {
    yield game.$plugins['workcrafts']["Black Cutscene"].show();
    game.loadmap("办公室");
    game.movehero(8,16);
    game.$plugins['workcrafts']["Black Cutscene"].hide();
}

function *进入校长() {
    game.loadmap("校长办公室");
    game.movehero(8,16);
}

function *进入宿舍() {
    game.loadmap("宿舍");
    game.movehero(5,10);
}

function *进入体育室() {
    game.loadmap("体育室");
    game.movehero(5,10);
}

function *进入图书馆() {
    game.loadmap("图书馆");
    game.movehero(5,10);
}

function *进入1年纪() {
    game.loadmap("班级");
    game.movehero(5,10);
}

function *进入2年纪() {
    game.loadmap("班级2");
    game.movehero(5,10);
}

function *进入3年纪() {
    game.loadmap("班级3");
    game.movehero(5,10);
}

function *得到西瓜刀() {
    game.getgoods('小草', 1);
    yield game.msg("得到【小草】");
}

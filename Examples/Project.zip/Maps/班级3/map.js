function *start() {
}

function *回一中() {
    game.loadmap("榆林一中");
    game.movehero(11,23);
}

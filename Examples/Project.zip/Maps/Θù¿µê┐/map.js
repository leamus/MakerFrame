function *start() {
    yield game.msg("门房", false);
    game.createrole({RId: "荔竹", $bx: 6, $by: 10});
    game.f["荔竹"] = 'game.msg("开关置0并且保存")';
    game.gd.开关1=0;
}

function *npc荔竹() {
    game.createrole("战士");
    game.moverole("战士", 4,10);
    game.f["战士"] =()=>{game.say('战士', '???')};
}

function *门房出门(){
    game.loadmap("榆林一中");
    game.movehero(16,24);
}

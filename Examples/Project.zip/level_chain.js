
//升级脚本
function *commonLevelUpScript(combatant) {

    let level = 0;  //当前经验可达到的级别
    let nextExp = 10;   //下一级别的经验


    //升级条件
    while(nextExp <= combatant.$properties.EXP) {
        nextExp = nextExp * 2;
        ++level;
    }


    //升级结果
    while(level > combatant.$properties.level) {

        ++combatant.$properties.level;

        combatant.$properties.HP[0] = combatant.$properties.HP[1] = combatant.$properties.HP[2] = parseInt(combatant.$properties.HP[2] * 1.1);
        combatant.$properties.MP[0] = combatant.$properties.MP[1] = parseInt(combatant.$properties.MP[1] * 1.1);
        combatant.$properties.attack = parseInt(combatant.$properties.attack * 1.1);
        combatant.$properties.defense = parseInt(combatant.$properties.defense * 1.1);
        combatant.$properties.power = parseInt(combatant.$properties.power * 1.1);
        combatant.$properties.luck = parseInt(combatant.$properties.luck * 1.1);
        combatant.$properties.speed = parseInt(combatant.$properties.speed * 1.1);


        /*game.run(
            'yield game.msg(\"%1升为%2级\");'.arg(combatant.$name).arg(combatant.$properties.level)
        );*/
        yield game.msg('%1升为%2级'.arg(combatant.$name).arg(combatant.$properties.level), 20, '', 0, 0b11);


        if(combatant.$name === 'killer') {
            switch(combatant.$properties.level) {
            case 1:
                game.getskill(combatant, '恢复血量');
                yield game.msg('%1 获得技能 %2'.arg(combatant.$name).arg('恢复血量'), 20, '', 0, 0b11);
                break;
            }
        }
    }

    return level;
}

//targetLeve级别对应需要达到的 各项属性 的算法（升级时会设置，可选；注意：只增不减）
function commonLevelAlgorithm(combatant, targetLevel) {
    if(targetLevel <= 0)
        return null;

    let level = 1;  //级别
    let exp = 10;   //级别的经验

    while(level < targetLevel) {
        exp = exp * 2;
        ++level;
    }

    return {EXP: exp};
}
